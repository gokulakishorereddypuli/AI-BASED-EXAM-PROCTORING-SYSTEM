var count=0;
var c=0;
var a = document.getElementById('aa');
var b = document.getElementById('bb');
var c = document.getElementById('cc');
var d = document.getElementById('dd');
var e = document.getElementById('ee');
var f = document.getElementById('ff');
var g = document.getElementById('gg');
var h = document.getElementById('hh');
var i = document.getElementById('ii');
var j = document.getElementById('jj');
var w = document.getElementById('ww');
var aa = document.getElementById('A12');
var bb = document.getElementById('B12');
var cc = document.getElementById('C');
var dd = document.getElementById('D');
var ee = document.getElementById('E');
var ff = document.getElementById('F');
var gg = document.getElementById('G');
var hh = document.getElementById('H');
var ii = document.getElementById('I');
var jj = document.getElementById('J');
var kk = document.getElementById('K');
var ll = document.getElementById('L');
var mm = document.getElementById('M');
var nn = document.getElementById('N');
var oo = document.getElementById('O');
var pp = document.getElementById('P');
var qq = document.getElementById('Q');
var rr = document.getElementById('R');
var ss = document.getElementById('S');
var tt = document.getElementById('T');
var uu = document.getElementById('U');
var vv = document.getElementById('V');
var ww = document.getElementById('W');
var xx = document.getElementById('X');
var yy = document.getElementById('Y');
var zz = document.getElementById('Z');
var aaa = document.getElementById('AA');
var bbb = document.getElementById('BB');
var ccc = document.getElementById('CC');
var ddd = document.getElementById('DD');
var eee = document.getElementById('EE');
var fff = document.getElementById('FF');
var ggg = document.getElementById('GG');
var hhh = document.getElementById('HH');
var iii = document.getElementById('II');
var jjj = document.getElementById('JJ');
var kkk = document.getElementById('KK');
var lll = document.getElementById('LL');
var ip = document.getElementById('inp');
var CN = document.getElementById('cn');
var nm = document.getElementById('name');
// var st = document.getElementById('fr');




function one(){
    b.style.display='block';
    a.style.display='none';
    a.style.backgroundColor='white';

}
function onec(){
    b.style.display='block';
    a.style.display='none';
    count+=1;

}

function clrr1()
{
    aa.style.backgroundColor='black';
    
}
function ck1c(){
    aa.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(clrr1,200);
    setTimeout(onec, 700);
}



function clrr2()
{
    bb.style.backgroundColor='black';
    
}

function ck2(){
    bb.style.backgroundColor='white';
    setTimeout(clrr2,200);
    setTimeout(one, 700);
}


function clrr3()
{
    cc.style.backgroundColor='black';
    
}

function ck3(){
    cc.style.backgroundColor='white';
    setTimeout(clrr3,200);
    setTimeout(one, 700);
}


function clrr4()
{
    dd.style.backgroundColor='black';
    
}

function ck4(){
    dd.style.backgroundColor='white';
    setTimeout(clrr4,200);
    setTimeout(one, 700);
}


//-----------------------------------------------------------------------------------------------------------------------



function c1(){
    ee.style.backgroundColor='black';
}



function ck5(){
    ee.style.backgroundColor='white';
    setTimeout(c1,200);
    setTimeout(two,700);
}
function c2(){
    ff.style.backgroundColor='black';
}



function ck6c(){
    ff.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(c2,200);
    setTimeout(twoc,700);
}
function c3(){
    gg.style.backgroundColor='black';
}



function ck7(){
    gg.style.backgroundColor='white';
    setTimeout(c3,200);
    setTimeout(two,700);
}
function c4(){
    hh.style.backgroundColor='black';
}
function ck8(){
    hh.style.backgroundColor='white';
    setTimeout(c4,200);
    setTimeout(two,700);
}
function two(){
    c.style.display='block';
    b.style.display='none';
 }
 function twoc(){
 
     c.style.display='block';
     b.style.display='none';
     count+=1;
  }
//-----------------------------------------------------------------------------------------------------------------------------------------------

function ca1(){
    ii.style.backgroundColor='black';
}
function ck9(){
    ii.style.backgroundColor='white';
    setTimeout(ca1,200);
    setTimeout(three,700);
}
function ca2(){
    jj.style.backgroundColor='black';
}
function ck10(){
    jj.style.backgroundColor='white';
    setTimeout(ca2,200);
    setTimeout(three,700);
}
function ca3(){
    kk.style.backgroundColor='black';
}
function ck11c(){
    kk.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca3,200);
    setTimeout(threec,700);
}
function ca4(){
    ll.style.backgroundColor='black';
}
function ck12(){
    ll.style.backgroundColor='white';
    setTimeout(ca4,200);
    setTimeout(three,700);
}
function three(){
    d.style.display='block';
    c.style.display='none';

}
function threec(){
    d.style.display='block';
    c.style.display='none';
    count+=1;

}
//--------------------------------------------------------------------------------------------------
function ca5(){
    mm.style.backgroundColor='black';
}
function ck13(){
    mm.style.backgroundColor='white';
    setTimeout(ca5,200);
    setTimeout(four,700);
}
function ca6(){
    nn.style.backgroundColor='black';
}
function ck14c(){
    nn.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca6,200);
    setTimeout(fourc,700);
}
function ca7(){
    oo.style.backgroundColor='black';
}
function ck15(){
    oo.style.backgroundColor='white';
    setTimeout(ca7,200);
    setTimeout(four,700);
}
function ca8(){
    pp.style.backgroundColor='black';
}
function ck16(){
    pp.style.backgroundColor='white';
    setTimeout(ca8,200);
    setTimeout(four,700);
}
function four(){
    e.style.display='block';
    d.style.display='none';
    
}
function fourc(){
    e.style.display='block';
    d.style.display='none';
    count+=1;
    
}
//--------------------------------------------------------------------------------------------------------
function ca9(){
    qq.style.backgroundColor='black';
}
function ck17c(){
    qq.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca9,200);
    setTimeout(fivec,700);
}
function ca10(){
    rr.style.backgroundColor='black';
}
function ck18(){
    rr.style.backgroundColor='white';
    setTimeout(ca10,200);
    setTimeout(five,700);
}
function ca11(){
    ss.style.backgroundColor='black';
}
function ck19(){
    ss.style.backgroundColor='white';
    setTimeout(ca11,200);
    setTimeout(five,700);
}
function ca12(){
    tt.style.backgroundColor='black';
}
function ck20(){
    tt.style.backgroundColor='white';
    setTimeout(ca12,200);
    setTimeout(five,700);
}

function five(){
    f.style.display='block';
    e.style.display='none';
    
}
function fivec(){
    f.style.display='block';
    e.style.display='none';
    count+=1;  
}
//------------------------------------------------------------------------------------------------------------------
function ca13(){
    uu.style.backgroundColor='black';
}
function ck21c(){
    uu.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca13,200);
    setTimeout(sixc,700);
}
function ca14(){
    vv.style.backgroundColor='black';
}
function ck22(){
    vv.style.backgroundColor='white';
    setTimeout(ca14,200);
    setTimeout(six,700);
}
function ca15(){
    ww.style.backgroundColor='black';
}
function ck23(){
    ww.style.backgroundColor='white';
    setTimeout(ca15,200);
    setTimeout(six,700);
}
function ca16(){
    xx.style.backgroundColor='black';
}
function ck24(){
    xx.style.backgroundColor='white';
    setTimeout(ca16,200);
    setTimeout(six,700);
}
function six(){
    g.style.display='block';
    f.style.display='none';
}
function sixc(){
    g.style.display='block';
    f.style.display='none';
    count+=1;
}
//---------------------------------------------------------------------------------------------------------------------------
function ca17(){
    yy.style.backgroundColor='black';
}
function ck25(){
    yy.style.backgroundColor='white';
    setTimeout(ca17,200);
    setTimeout(seven,700);
}
function ca18(){
    zz.style.backgroundColor='black';
}
function ck26c(){
    zz.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca18,200);
    setTimeout(sevenc,700);
}
function ca19(){
    aaa.style.backgroundColor='black';
}
function ck27(){
    aaa.style.backgroundColor='white';
    setTimeout(ca19,200);
    setTimeout(seven,700);
}
function ca20(){
    bbb.style.backgroundColor='black';
}
function ck28(){
    bbb.style.backgroundColor='white';
    setTimeout(ca20,200);
    setTimeout(seven,700);
}
function seven(){
    h.style.display='block';
    g.style.display='none';
    
}
function sevenc(){
    h.style.display='block';
    g.style.display='none';
    count+=1;
    
}
//----------------------------------------------------------------------------------------------------------------------------------------
function ca21(){
    ccc.style.backgroundColor='black';
}
function ck29(){
    ccc.style.backgroundColor='white';
    setTimeout(ca21,200);
    setTimeout(eight,700);
}
function ca22(){
    ddd.style.backgroundColor='black';
}
function ck30(){
    ddd.style.backgroundColor='white';
    setTimeout(ca22,200);
    setTimeout(eight,700);
}
function ca23(){
    eee.style.backgroundColor='black';
}
function ck31(){
    eee.style.backgroundColor='white';
    setTimeout(ca23,200);
    setTimeout(eight,700);
}
function ca24(){
    fff.style.backgroundColor='black';
}
function ck32c(){
    fff.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca24,200);
    setTimeout(eightc,700);
}
function eight(){
    i.style.display='block';
    h.style.display='none';
    
}
function eightc(){
    i.style.display='block';
    h.style.display='none';
    count+=1;
    
}
//---------------------------------------------------------------------------------------------------------------------------------------------
function ca24(){
    ggg.style.backgroundColor='black';
}
function ck33c(){
    ggg.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca24,200);
    setTimeout(ninec,700);
}
function ca25(){
    hhh.style.backgroundColor='black';
}
function ck34(){
    hhh.style.backgroundColor='white';
    setTimeout(ca25,200);
    setTimeout(nine,700);
}
function ca26(){
    iii.style.backgroundColor='black';
}
function ck35(){
    iii.style.backgroundColor='white';
    setTimeout(ca26,200);
    setTimeout(nine,700);
}
function ca27(){
    jjj.style.backgroundColor='black';
}
function ck36(){
    jjj.style.backgroundColor='white';
    setTimeout(ca27,200);
    setTimeout(nine,700);
}
function nine(){
    j.style.display='block';
    i.style.display='none';
    
}
function ninec(){
    j.style.display='block';
    i.style.display='none';
    count+=1;
    
}
//--------------------------------------------------------------------------------------------------------------------------------------------------------
function ca27(){
    kkk.style.backgroundColor='black';
}
function ck37(){
    kkk.style.backgroundColor='white';
    setTimeout(ca27,200);
    setTimeout(ten,700);
}
function ca28(){
    lll.style.backgroundColor='black';
}
function ck38c(){
    lll.style.backgroundColor='rgb(60, 163, 23)';
    setTimeout(ca28,200);
    setTimeout(tenc,700);
}
function ten(){
    document.getElementById('jj1').style.display='block';
    j.style.display='none';
    var mb1= document.getElementById('sid').value;
    var rol=document.getElementById('roll').value;
    document.getElementById('rol').value=rol;
    document.getElementById('nam').value=mb1;
    document.getElementById('scor').value=count;  
    
}
function tenc(){
    document.getElementById('jj1').style.display='block';
    j.style.display='none';
    count += 1;
    var mb = document.getElementById('sid').value;
    // document.getElementById('GG1').innerHTML=mb;
    // document.getElementById('HH1').innerHTML=count;
    var rol=document.getElementById('roll').value;
    document.getElementById('rol').value=rol;
    document.getElementById('nam').value=mb;
    document.getElementById('scor').value=count;   

}

// function sai(){
//     document.getElementById('aa1').style.display='none';
//     a.style.display='block';
//     var isfullscreen=false;
//     var spoofDetected=false;
//     elem=this.document.documentElement;
//     // function enterFullScreen ()
//     //   {
//         if (this.elem.requestFullscreen)
//         {
//           this.elem.requestFullscreen();
//         } else if (this.elem.mozRequestFullScreen) {
//           /* Firefox */
//           this.elem.mozRequestFullScreen();
//         } else if (this.elem.webkitRequestFullscreen) {
//           /* Chrome, Safari and Opera */
//           this.elem.webkitRequestFullscreen();
//         } else if (this.elem.msRequestFullscreen) {
//           /* IE/Edge */
//           this.elem.msRequestFullscreen();
//         }
//         this.isfullscreen=true;
//         this.spoofDetected=false;
//       }
// }
function onc(){
    var bn = document.getElementById('sid');
    if(bn.value.length>0){
        document.getElementById('strt').style.display='block';
        document.getElementById('roll').style.display='block';

    }
    
}


// --------------------------------------------------------------
